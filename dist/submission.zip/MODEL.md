# Alpha Connectome submission

Uses supplied competition weights and the two-target streaming callback.
All recurrent state and filters reset between sequences.
Inference is offline, CPU-only, with one runtime compute thread.
Model SHA256: `d920986b8c42b256c652e9f695e6ca52af1be7c3ecc88cd0596de41ed5653a45`
The hidden test volume/CPU is unspecified; runtime compliance needs platform evidence.
