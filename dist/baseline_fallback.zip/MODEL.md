# Alpha Connectome submission

Uses supplied competition weights and the two-target streaming callback.
All recurrent state and filters reset between sequences.
Inference is offline, CPU-only, with one runtime compute thread.
Model SHA256: `321ec67b93f3c5dde2c0901ca4532072dad5f65753c2e6519e93ea3555f6a6fd`
The hidden test volume/CPU is unspecified; runtime compliance needs platform evidence.
